define({
  "name": "HMRestAPIDoc",
  "version": "0.1.0",
  "description": "apiDoc basic",
  "title": "Custom apiDoc browser title",
  "url": "http://127.0.0.1:3000",
  "sampleUrl": "http://127.0.0.1:3000",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-06-28T14:04:05.104Z",
    "url": "http://apidocjs.com",
    "version": "0.23.0"
  }
});
